import express from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Path resolution safe for both ESM (tsx dev mode) and CJS (bundled by esbuild)
const getPaths = () => {
  try {
    if (typeof __filename !== 'undefined' && typeof __dirname !== 'undefined') {
      return { filename: __filename, dirname: __dirname };
    }
  } catch (e) {}

  const filename = fileURLToPath(import.meta.url);
  const dirname = path.dirname(filename);
  return { filename, dirname };
};

const { filename: activeFilename, dirname: activeDirname } = getPaths();

// Initialize Gemini SDK with telemetry header
const apiKey = process.env.GEMINI_API_KEY;
if (!apiKey) {
  console.warn("WARNING: GEMINI_API_KEY environment variable is not defined");
}

const ai = new GoogleGenAI({
  apiKey: apiKey || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

async function startServer() {
  const app = express();
  app.use(express.json());

  // 1. API: LINE Notify/Messaging API Proxy (Bypasses browser CORS restriction)
  app.post('/api/line-notify', async (req, res) => {
    const { token, message, apiType = 'messaging_api' } = req.body;

    if (!token) {
      return res.status(400).json({ success: false, error: 'LINE API Token is required' });
    }
    if (!message) {
      return res.status(400).json({ success: false, error: 'Message content is required' });
    }

    try {
      if (apiType === 'messaging_api') {
        console.log('Sending message via LINE Official Account Messaging API (Broadcast)...');
        
        const response = await fetch('https://api.line.me/v2/bot/message/broadcast', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            messages: [
              {
                type: 'text',
                text: message
              }
            ]
          })
        });

        if (response.ok) {
          return res.json({ success: true, message: 'Message successfully broadcasted via LINE Messaging API!' });
        } else {
          const errData = await response.json().catch(() => ({}));
          return res.status(400).json({
            success: false,
            error: errData.message || errData.details?.[0]?.message || `LINE API responded with status ${response.status}`
          });
        }
      } else {
        // Legacy LINE Notify
        console.log('Sending notification via Legacy LINE Notify API (Deprecated)...');
        
        const response = await fetch('https://notify-api.line.me/api/notify', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': `Bearer ${token}`
          },
          body: new URLSearchParams({ message })
        });

        const data = await response.json();

        if (response.ok && data.status === 200) {
          return res.json({ success: true, message: 'Message successfully sent to LINE!' });
        } else {
          return res.status(400).json({ 
            success: false, 
            error: data.message || 'Legacy LINE Notify API returned failure (Discontinued on March 31, 2025).' 
          });
        }
      }
    } catch (err: any) {
      console.error('Error calling LINE API:', err);
      return res.status(500).json({ 
        success: false, 
        error: err.message || 'Internal Server Error' 
      });
    }
  });

  // 2. API: AI Secretarial Agent endpoint runs server-side Gemini
  app.post('/api/agent/run', async (req, res) => {
    const { prompt, agentPersona, lineToken } = req.body;

    if (!prompt) {
      return res.status(400).json({ success: false, error: 'Goal prompt is required' });
    }

    const personaDescriptions: Record<string, string> = {
      secretary: 'เลขาฯ มืออาชีพ สุภาพ เรียบร้อย ละเอียดรอบคอบ และคอยดูแลตารางงานได้ไร้ที่ติ',
      pm: 'ผู้ช่วยผู้จัดการโครงการ (Project Manager) เน้นความชัดเจน แบ่งงานเป็นขั้นตอน และติดตามความคืบหน้าอย่างเป็นระบบ',
      coach: 'โค้ชสร้างแรงบันดาลใจ (Motivational Coach) ใช้คำพูดเติมพลังบวก กระตุ้นทีม และเปี่ยมไปด้วยพลังขับเคลื่อน',
      admin: 'ผู้ดูแลระบบและประกาศด่วน (System Co-ordinator) ชัดเจน กระชับ ตรงประเด็น ใช้ประกาศแจ้งข่าวสารด่วน',
    };

    const selectedPersona = personaDescriptions[agentPersona] || personaDescriptions.secretary;

    try {
      console.log(`Analyzing instruction using Gemini: "${prompt}" (Persona: ${agentPersona})`);

      // Define the structured schema we expect from Gemini
      const responseSchema = {
        type: Type.OBJECT,
        properties: {
          intent: {
            type: Type.STRING,
            description: "สรุปเป้าหมายหรือความต้องการของผู้ใช้ในประโยคสั้นๆ",
          },
          reasoningSteps: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "ลำดับขั้นตอนการทำงานของผู้ใช้นี้ (3-4 ขั้นตอนภาษาไทย) เช่น วิเคราะห์เนื้อหา, ร่างประโยค, จัดแต่งความสวยงาม",
          },
          draftMessage: {
            type: Type.STRING,
            description: "ร่างข้อความที่จะส่งลงไลน์ ออกแบบและจัดรูปแบบอย่างสวยงาม จัดย่อหน้า ใช้กระสุนนำ (bullet points) เว้นวรรคอย่างเหมาะสม และมีอิโมจิ (emojis) ตกแต่งอย่างเหมาะสม ดูเป็นมืออาชีพ มีความสุภาพ",
          },
          automationType: {
            type: Type.STRING,
            description: "ประเภทของการเตือนภัยหรือแอปพลิเคชัน: announcement, reminder, todo หรือ creative",
          },
          scheduleTime: {
            type: Type.STRING,
            description: "รายละเอียดวันเวลาหากเป็นสิ่งที่ต้องกำหนดตารางเวลา (เช่น ทุกเช้าวันจันทร์ 9:00 น., 25 พ.ค. 14:00 น.) หากไม่มีให้ปล่อยว่าง",
          },
          targetAudience: {
            type: Type.STRING,
            description: "คำอธิบายกลุ่มเป้าหมายผู้รับสาร เช่น กลุ่มเพื่อนร่วมงาน, กลุ่มครอบครัว หรือสำหรับการแจ้งเตือนส่วนตัว",
          }
        },
        required: ["intent", "reasoningSteps", "draftMessage", "automationType", "targetAudience"],
      };

      const systemInstruction = `คุณคือ "LINE AI Secretarial Agent" (เลขา AI ส่วนตัว).
หน้าที่ของคุณคือรับคำสั่งจากผู้ใช้เพื่อสั่งงาน เขียนประกาศ แต่งโพสต์ ตั้งเตือน หรือสรุปข้อความ เพื่อนำมาโพสต์หรือส่งแจ้งเตือนในระบบ LINE ของผู้ใช้
บุคลิกหลักของคุณคือ: ${selectedPersona}

กรุณาทำความเข้าใจเจตจำนงของผู้ใช้อย่างละเอียด และสร้างสรรค์ข้อความที่:
1. ภาษาไทยธรรมชาติ สุภาพ เรียบร้อย น่าอ่าน เหมาะสมกับบุคลิกที่เลือก
2. จัดวางหน้าอย่างประณีต มีหัวข้อหลัก มีจุดกระสุนนำ (bullet points) ย่อหน้า และช่องว่างสายตาที่ดี
3. มีการใช้อิโมจิสอดคล้องกับเนื้อความอย่างมีศิลปะ ไม่รกรุงรัง แต่ดึงดูดสายตา
4. มีข้อมูลครบถ้วนตามที่ร้องขอ

คุณต้องส่งผลลัพธ์กลับมาในรูปแบบ JSON ตาม Schema ที่กำหนดให้เท่านั้น`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          systemInstruction,
          responseMimeType: "application/json",
          responseSchema,
          temperature: 0.7,
        },
      });

      const responseText = response.text;
      if (!responseText) {
        throw new Error('No response text retrieved from Gemini Model.');
      }

      const agentResult = JSON.parse(responseText.trim());

      return res.json({
        success: true,
        agentResult,
      });

    } catch (err: any) {
      console.error('Gemini execution error:', err);
      return res.status(500).json({ 
        success: false, 
        error: err.message || 'Failed to analyze task with AI agent.' 
      });
    }
  });

  // 2.2. API: AI Calendar Summarizer
  app.post('/api/agent/summarize-calendar', async (req, res) => {
    const { events, agentPersona } = req.body;

    if (!events || !Array.isArray(events)) {
      return res.status(400).json({ success: false, error: 'Events array is required' });
    }

    const personaDescriptions: Record<string, string> = {
      secretary: 'เลขาฯ มืออาชีพ สุภาพ เรียบร้อย ละเอียดรอบคอบ และคอยดูแลตารางงานได้ไร้ที่ติ',
      pm: 'ผู้ช่วยผู้จัดการโครงการ (Project Manager) เน้นความชัดเจน แบ่งงานเป็นขั้นตอน และติดตามความคืบหน้าอย่างเป็นระบบ',
      coach: 'โค้ชสร้างแรงบันดาลใจ (Motivational Coach) ใช้คำพูดเติมพลังบวก กระตุ้นทีม และเปี่ยมไปด้วยพลังขับเคลื่อน',
      admin: 'ผู้ดูแลระบบและประกาศด่วน (System Co-ordinator) ชัดเจน กระชับ ตรงประเด็น ใช้ประกาศแจ้งข่าวสารด่วน',
    };

    const selectedPersona = personaDescriptions[agentPersona] || personaDescriptions.secretary;

    try {
      console.log(`Summarizing ${events.length} Google Calendar events using Gemini with persona "${agentPersona}"`);

      const eventsText = events.map((ev: any, index: number) => {
        const start = ev.start?.dateTime || ev.start?.date || '';
        const end = ev.end?.dateTime || ev.end?.date || '';
        const summary = ev.summary || 'ไม่มีชื่อหัวข้อนัดหมาย';
        const description = ev.description || '';
        return `นัดหมายที่ ${index + 1}:
- หัวข้อ: ${summary}
- เริ่ม: ${start}
- สิ้นสุด: ${end}
- รายละเอียดเพิ่มเติม: ${description}`;
      }).join('\n\n');

      const systemInstruction = `คุณคือ "LINE AI Secretarial Agent" (เลขา AI ส่วนตัว).
หน้าที่ของคุณคือรับตารางการนัดหมายจาก Google Calendar และสร้างข้อความประกาศ/สรุปตารางงานสำหรับส่งไปใน LINE Group อย่างเป็นระเบียบ เรียบร้อย และสวยงาม
บุคลิกหลักของคุณคือ: ${selectedPersona}

กรุณาสรุปนัดหมายที่ส่งมาดังนี้:
1. ภาษาไทยธรรมชาติ สุภาพ เรียบร้อย น่าอ่าน สอดคล้องกับหัวโขน/บุคลิก
2. จัดวางหน้าอย่างประณีต มีหัวข้อหลัก (เช่น 📅 สรุปอัปเดตปฏิทินงานการทำงานทีม) มีจุดกระสุนนำ (bullet points) ย่อหน้า และช่องว่างสายตาที่ดี
3. มีการใช้อิโมจิที่สื่อถึงความร่วมมือ นัดหมาย เวลา และแผนงานอย่างสร้างสรรค์
4. เรียงตามตารางเวลา แสดงช่วงเวลาให้ชัดเจนสะดุดตา

คุณต้องตอบกลับข้อมูลเป็นร่างข้อความภาษาไทยจัดรูปแบบสวยงามแบบ Plain string ที่ผู้ใช้สามารถนำไปส่งต่อได้ทันที`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: `นี่คือรายการดึงคิวจาก Google Calendar:\n\n${eventsText}\n\nกรุณาร่างประมวลสรุปตารางเพื่อจัดส่งให้กับกลุ่มแชท LINE เผยแพร่งานอัจฉริยะค่ะ`,
        config: {
          systemInstruction,
          temperature: 0.7,
        },
      });

      const draftMessage = response.text || '';

      return res.json({
        success: true,
        draftMessage,
      });

    } catch (err: any) {
      console.error('Gemini calendar summary error:', err);
      return res.status(500).json({ 
        success: false, 
        error: err.message || 'Failed to summarize calendar events.' 
      });
    }
  });

  // 2.3. API: AI Interactive Chat & Research Grounding
  app.post('/api/agent/chat', async (req, res) => {
    const { messages, agentPersona } = req.body;

    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ success: false, error: 'Messages array is required' });
    }

    const personaDescriptions: Record<string, string> = {
      secretary: 'เลขาฯ มืออาชีพ สุภาพ เรียบร้อย ละเอียดรอบคอบ และคอยช่วยเหลือค้นคว้าข้อมูลสนับสนุนงานอย่างสุขุม',
      pm: 'ผู้ช่วยผู้จัดการโครงการ (Project Manager) เน้นการวางแผน งานเป็นสัดส่วน วิเคราะห์เป้าหมาย และติดตามงานอย่างเฉียบขาด',
      coach: 'โค้ชสร้างแรงบันดาลใจ (Motivational Coach) เติมพลังเชิงบวก ให้คำแนะนำอบอุ่น เพื่อการทำงานร่วมกันอย่างมีความสุข',
      admin: 'ผู้ดูแลระบบและแอดมินประสานงาน คมชัด กระชับ ตรงสิทธิ์ข้อตกลง ดึงสถิติจริงและข้อเท็จจริงอย่างตรงไปตรงมา',
    };

    const selectedPersona = personaDescriptions[agentPersona] || personaDescriptions.secretary;

    try {
      console.log(`AI Chat request received with ${messages.length} messages. Persona: ${agentPersona}`);

      const systemInstruction = `คุณคือ "LINE AI Assistant & Research Secretary" (เลขาผู้ช่วยวิจัยปัญญาประดิษฐ์และโต้ตอบสัจธรรม).
หน้าที่ของคุณคือช่วยโต้ตอบ ให้ข้อมูล ค้นหาข้อมูลล่าสุดบนเว็บจากสถานการณ์รอบมิติ เพื่อให้คำแนะนำที่ดีเยี่ยม และแนะนำร่างข้อความประกาศ, การเตือนภัยนัดหมาย, คำอวยพร หรือโปรเจกต์งานต่างๆ ที่เหมาะสมเพื่อใช้จัดส่ง/กระจายข่าวสารในกลุ่มแชท LINE

คุณต้องตอบสนองภายใต้บุคลิกและน้ำเสียงของบุคลิกภาพนี้: ${selectedPersona}

คำแนะนำของระบบ:
1. เสนอตัวช่วยวิจัย ให้ข้อมูลคำแนะนำแก่ผู้ใช้อย่างตรงประเด็นและมีความสุภาพนอบน้อมในฐานะเลขาฯ/ผู้เชี่ยวชาญภาษาไทยธรรมชาติ โดยอยู่ภายใต้ scope ของงานเลขาฯ, LINE notification, การสื่อสารประชาสัมพันธ์, งานออฟฟิศ หรือโปรเจกต์แผนงาน
2. หากเนื้อหาเกี่ยวข้องกับข่าวสาร ข้อมูลสภาพภูมิอากาศ สุขภาพ เทคโนโลยี ข้อเท็จจริง หรือเรื่องราวที่ต้องอ้างอิงความจริงในปัจจุบัน คุณสามารถสืบค้นข้อมูลล่าสุดจากอินเทอร์เน็ตได้โดยตรง เพื่อความถูกต้องสูงสุด
3. จัดหน้าและเน้นคำสำคัญด้วย Markdown อย่างสวยงาม ทำเป็นย่อหน้า หรือหัวข้อย่อยเพื่อให้อ่านง่าย เพื่อให้ผู้ใช้สามารถอ่านคำแนะนำหรือก๊อปปี้ไปแชร์ต่อในกลุ่มไลน์ได้ทันที
4. มอบข้อเสนอแนะและ "ร่างข้อความแนะนำ" ที่เอาไปโพสต์ลง LINE ได้สะดวกให้ผู้ใช้เอาไปคัดลอกได้ทันที`;

      // Map communication history for Gemini API
      const contents = messages.map((m: any) => ({
        role: m.role === 'user' ? 'user' : 'model',
        parts: [{ text: m.text }]
      }));

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: contents,
        config: {
          systemInstruction,
          temperature: 0.7,
          tools: [{ googleSearch: {} }],
        },
      });

      const text = response.text || '';
      const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];

      // Extract research source references
      const sources = groundingChunks.map((chunk: any) => {
        if (chunk.web) {
          return {
            title: chunk.web.title || 'แหล่งอ้างอิงข้อมูลเว็บ',
            uri: chunk.web.uri || ''
          };
        }
        return null;
      }).filter(Boolean);

      return res.json({
        success: true,
        text,
        sources
      });

    } catch (err: any) {
      console.error('Gemini chat execution error:', err);
      return res.status(500).json({ 
        success: false, 
        error: err.message || 'Failed to generate AI response.' 
      });
    }
  });

  // 3. SPA Handlers & Dev Server Setup
  if (process.env.NODE_ENV !== 'production') {
    console.log('Mounting Vite dev server middleware in Express...');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    console.log('Serving production static build files from dist...');
    app.use(express.static(path.resolve(activeDirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(activeDirname, 'dist/index.html'));
    });
  }

  // 4. Start the server on port 3000 (Required by infra, listening on 0.0.0.0)
  const port = 3000;
  app.listen(port, '0.0.0.0', () => {
    console.log(`🚀 AI Secretarial Agent App Server now running on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal server start error:', err);
});
