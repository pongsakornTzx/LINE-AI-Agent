const fs = require('fs');
const content = fs.readFileSync('src/App.tsx', 'utf8');
const lines = content.split('\n');

const line512Index = 511;
const line703Index = 702;

lines[line512Index] = '            <span className="text-slate-800 hidden md:inline">|</span>';
lines.splice(line512Index + 1, line703Index - line512Index);

fs.writeFileSync('src/App.tsx', lines.join('\n'));
console.log('Fixed src/App.tsx pt 3');
