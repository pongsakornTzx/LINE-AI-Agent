const fs = require('fs');
const content = fs.readFileSync('src/App.tsx', 'utf8');
const lines = content.split('\n');

const startIndex = lines.findIndex(l => l.includes('นำร่างคำแนะนำบรรจุเข้ากล่องขัดเกลาแล้วค่ะ ตรวจสอบและดัดแปลงส่งไลน์ทางฝั่งขวาได้เลยนะคะ!'));
const endIndex = lines.findIndex(l => l.includes('// --- Show custom Toast utility ---'));

if (startIndex > 0 && endIndex > 0) {
  lines.splice(startIndex + 1, endIndex - startIndex - 1, '  };', '');
  fs.writeFileSync('src/App.tsx', lines.join('\n'));
  console.log('Fixed src/App.tsx');
}
