const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

// replace result.token with result.accessToken
content = content.replaceAll('result.token', 'result.accessToken');

// replace text with prompt in presets map
// Wait, the error is: src/App.tsx(672,61): error TS2339: Property 'text' does not exist on type '{ title: string; desc: string; prompt: string; icon: string; persona: string; }'.
// Let's replace 'p.text' with 'p.prompt'.
content = content.replaceAll('p.text', 'p.prompt');

fs.writeFileSync('src/App.tsx', content);
console.log('Fixed token and p.text -> p.prompt');
