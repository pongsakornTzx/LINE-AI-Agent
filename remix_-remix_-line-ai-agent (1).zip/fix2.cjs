const fs = require('fs');
const content = fs.readFileSync('src/App.tsx', 'utf8');
const lines = content.split('\n');

const startIndex = lines.findIndex(l => l.includes('นำร่างคำแนะนำบรรจุเข้ากล่องขัดเกลาแล้วค่ะ ตรวจสอบและดัดแปลงดึงส่งไลน์ทางฝั่งขว'));
const endIndex = lines.findIndex((l, i) => i > startIndex && l.trim() === '};');

if (startIndex > 0 && endIndex > 0) {
  lines.splice(startIndex, endIndex - startIndex + 1, 
    "    showToast('✨ นำร่างคำแนะนำบรรจุเข้ากล่องขัดเกลาแล้วค่ะ ตรวจสอบและดัดแปลงดึงส่งไลน์ทางฝั่งขวาได้เลยนะคะ!', 'success');",
    "  };"
  );
  fs.writeFileSync('src/App.tsx', lines.join('\n'));
  console.log('Fixed src/App.tsx pt 2');
} else {
  console.log('Could not find', startIndex, endIndex);
}
