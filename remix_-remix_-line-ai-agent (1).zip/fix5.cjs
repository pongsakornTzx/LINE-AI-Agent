const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

content = content.replaceAll('preset.text', 'preset.prompt');

fs.writeFileSync('src/App.tsx', content);
console.log('Fixed preset.text -> preset.prompt');
